import string
import random

CHARS = string.ascii_letters
DIGITS = string.digits

def random_pass(l=12):
    random_pass = ''.join(i for i in random.choices(CHARS + DIGITS, k=l))
    return random_pass
