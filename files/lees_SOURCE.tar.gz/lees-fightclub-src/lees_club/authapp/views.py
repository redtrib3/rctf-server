from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password, check_password
from django.views.decorators.csrf import csrf_exempt
import urllib.parse

from .models import Users
from os import system
from .pass_generator import random_pass

def username_exist(username: str) -> bool:
    try:
        user = Users.objects.get(username=username)
        if user: return True
    except Users.DoesNotExist:
        return False

def is_valid_URL(url: str)-> bool:
    try:
        parsed_url = urllib.parse.urlparse(url)
        return all([parsed_url.scheme, parsed_url.netloc])  

    except ValueError:
        return False

@csrf_exempt
def signup(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        conf_pass = request.POST.get('confirm_password')
        resetpass_url = request.POST.get('resetpass_url')
        
        if not is_valid_URL(resetpass_url):
            return render(request, 'signup.html', {'error': 'Reset URL doesn\'t look valid.'})
        
        username = username.replace('{','').replace('}','')
        
        if username_exist(username):
            return render(request, 'signup.html', {'error': 'Username already exists!'})

        if password != conf_pass:
            print(password, conf_pass)
            return render(request, 'signup.html',{'error':'Passwords do not match!'})

        new_user = Users(username=username, password=make_password(password), resetpass_url=resetpass_url)
        new_user.save()

        return redirect("/auth/signin")

    return render(request, 'signup.html')

def check_credentials(username, password):
    try:
        user = Users.objects.get(username=username)
        return check_password(password, user.password)

    except Users.DoesNotExist:
        return None

@csrf_exempt
def signin(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        s = check_credentials(username, password)
        if s:
            request.session['user_authenticated'] = True
            return redirect('/arena')
        else:
            return render(request, 'signin.html', {'error':'Incorrect Username or Password!'})

    return render(request, 'signin.html')


def send_reset_pass(reseturl: str):

    temp_pass = random_pass(l=12)
    try:
        cmd = f'curl -X POST {reseturl} -d \"tmp_pass={temp_pass}\" 2>/dev/null'
        system(cmd)

        return True, temp_pass

    except:
        return False

def set_new_pass(username, new_password):
    try:
        user = Users.objects.get(username=username)
        user.password = make_password(new_password)
        user.save()
        return True
    except User.DoesNotExist:
        return None


def reset_pass(request):
    if request.method == 'POST':
        username = request.POST.get('username')

        if not username_exist(username):
            return render(request, 'resetpass.html',{'msg':'Username does not exist'})

        reseturl = Users.objects.get(username=username).resetpass_url
        reset_res = send_reset_pass(reseturl)

        if reset_res[0]:
            setpass = set_new_pass(username, reset_res[1])

            if not setpass:
                return render(request, 'resetpass.html', {'msg': 'Error setting new pass, please try again'})

            return render(request, 'resetpass.html', {'msg': 'Reset password sent.'})

        return render(request, 'resetpass.html',{'msg':'Possible bad characters found in URL.'})

    return render(request, 'resetpass.html')

