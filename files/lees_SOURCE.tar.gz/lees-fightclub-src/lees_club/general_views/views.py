from django.shortcuts import render, redirect

# Create your views here.

def logout(request):
    request.session.clear()
    return redirect('/')

def index_view(request):
    return render(request, 'index.html')

def acc_dashboard(request):
    if request.session.get('user_authenticated', False):
        return render(request, 'arena.html')
    else:
        return redirect('/auth/signin')
