from django.urls import path
from . import views

urlpatterns = [
	path('notes',views.list_notes),
	path('notes/view/<int:id>', views.select_note_by_ID),
]
