# NotesCrypt - Secure and encrypted Notes

An Open Source Notes application with end-to-end encryption.
Your data is secure and encrypted in our servers(🇨🇭 ). Not even our server admins can read your files.


## What makes us your best choice?  
 * Encrypted data is hosted in Switzerland!

## About Us
Notescrypt is actively developed by our team at GlitchSecurity, a company that has been building Open-Source software since 2003 with contributors from around the world. 

## Installation
Development: Our developer guide provides instructions for setting up a local instance without HTTPS or our more advanced security features.
Production: It's really hard. please check [admin installation guide](http[:]//docs.notescryptraxeqwdx[.]io)

# Sponsor us

Our exciting sponsors:
1. @hooli
2. @google
3. @microsoft
4. @nsa
