from .models import Users

def username_exists(username: str) -> bool:
    try:
        user = Users.objects.get(username=username)
        if user: return True
    except Users.DoesNotExist:
        return False


def check_credentials(username, password):
    try:
        user = Users.objects.get(username=username)
        return check_password(password, user.password)

    except Users.DoesNotExist:
        return None

