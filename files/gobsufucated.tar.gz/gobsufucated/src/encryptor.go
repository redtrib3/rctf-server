package main

import (
	FMT_0xe5291e29 "fmt"
	MATH_0x9372f38f "math/rand"
	OS_0x10f52e43 "os"
)

var VAR_enc_0x82ea9b8f [50]int

func FUNC_Encrypt_0xffa7c6d1(VAR_p_0x57e3da5f *string) {
	MATH_0x9372f38f.Seed(0xc0ffee)
	VAR_i_0x4b3493a2 := 0
	for _, VAR_char_0x2b0d37fd := range *VAR_p_0x57e3da5f {
		VAR_payload_0x1f8c63e9 := MATH_0x9372f38f.Intn(100000) ^ int(VAR_char_0x2b0d37fd)
		VAR_enc_0x82ea9b8f[VAR_i_0x4b3493a2] = VAR_payload_0x1f8c63e9
		VAR_i_0x4b3493a2++
	}
	FMT_0xe5291e29.Println()
	for VAR_i_0x4b3493a2 := 0; VAR_i_0x4b3493a2 < len(*VAR_p_0x57e3da5f); VAR_i_0x4b3493a2++ {
		FMT_0xe5291e29.Print(VAR_enc_0x82ea9b8f[VAR_i_0x4b3493a2], " ")
	}
}

func main() {
	var VAR_choice_0xe3b148f9 int
	VAR_banner_0x82ea9b8f := `
 ------McD's encrypting machine-----
 
 1. Encrypt 
 2. Decrypt 
 3. Exit
 
 Choose an option:`
	for {
		FMT_0xe5291e29.Print(VAR_banner_0x82ea9b8f)
		FMT_0xe5291e29.Scan(&VAR_choice_0xe3b148f9)
		switch VAR_choice_0xe3b148f9 {
		case 1:
			var VAR_pass_0x9372f38f string
			FMT_0xe5291e29.Print("\n [+] Enter pass: ")
			FMT_0xe5291e29.Scan(&VAR_pass_0x9372f38f)
			FUNC_Encrypt_0xffa7c6d1(&VAR_pass_0x9372f38f)
		case 2:
			FMT_0xe5291e29.Println("\n \"Thats an exercise for the reader\" \n\t\t\t-Sun Tzu\n")
		case 3:
			OS_0x10f52e43.Exit(0)
		default:
			FMT_0xe5291e29.Println("[!] Error: Unknown option! ")
		}
	}
}

/*
49118 28574 68956 20259 11078 56389 58491 57923 50553 73641 3926 27303 69088 35658 19930 96573 65743 1331 68726 75069 50681 85386 99397 55056 27615 26949 82781 21340
*/
