<?php
session_start();

if (isset($_SESSION['username'])) {
    header('Location: dashboard.php');
    exit();
}

if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    //now thats secure!
    $db_host = getenv('MYSQL_HOST');
    $db_name = getenv('MYSQL_DBNAME');
    $db_user = getenv('MYSQL_USER');
    $db_pass = getenv('MYSQL_PASSWORD');

    $conn = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_pass);
    $stmt = $conn->prepare("SELECT password FROM users WHERE username=:user");
    $stmt->bindValue(':user', $user);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $hashed_password = $row['password'];

    if (password_verify($pass, $hashed_password)) {
        $_SESSION['username'] = $user;

        header('Location: dashboard.php');
        exit();
    } else {
        $error = 'Incorrect username or password';
    }
}
?>
